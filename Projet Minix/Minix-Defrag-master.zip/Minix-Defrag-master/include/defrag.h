#ifndef _DEFRAG_H_
#define _DEFRAG_H_

#include <stdlib.h>	

_PROTOTYPE( int defrag, (const char*)		);

#endif
