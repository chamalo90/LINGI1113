/*
netdb.h
*/

/* Open Group Base Specifications Issue 6 (not complete) */
#include <net/gen/netdb.h>
