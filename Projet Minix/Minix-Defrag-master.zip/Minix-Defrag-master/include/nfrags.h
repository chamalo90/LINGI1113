#ifndef _NFRAGS_H_
#define _NFRAGS_H_

#include <stdlib.h>			

_PROTOTYPE( int nfrags, (const char*)		);	

#endif
