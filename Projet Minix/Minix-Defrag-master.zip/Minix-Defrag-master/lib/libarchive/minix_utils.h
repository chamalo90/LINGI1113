#ifndef MINIX_UTILS_H
#define MINIX_UTILS_H
#include <minix/u64.h>
u64_t lshift64(u64_t x, unsigned short b);
#endif
