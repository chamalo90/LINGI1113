#!/bin/sh

export CC=cc
export MAKEOBJDIR=obj-ack

make $@
