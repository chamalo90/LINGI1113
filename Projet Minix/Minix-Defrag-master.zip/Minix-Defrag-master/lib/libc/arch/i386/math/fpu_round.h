#ifndef __FPU_RNDINT__
#define __FPU_RNDINT__

void fpu_rndint(double *value);
void fpu_remainder(double *x, double y);

#endif /* !defined(__FPU_RNDINT__) */
