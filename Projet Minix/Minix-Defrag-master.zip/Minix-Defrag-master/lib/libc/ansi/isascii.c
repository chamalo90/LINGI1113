#include	<ctype.h>

int (isascii)(int c) {
	return isascii(c);
}
