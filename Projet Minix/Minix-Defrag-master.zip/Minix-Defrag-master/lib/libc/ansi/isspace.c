#include	<ctype.h>

int (isspace)(int c) {
	return isspace(c);
}
