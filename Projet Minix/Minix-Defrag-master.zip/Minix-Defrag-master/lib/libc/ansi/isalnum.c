#include	<ctype.h>

int (isalnum)(int c) {
	return isalnum(c);
}
