#include	<ctype.h>

int (isdigit)(int c) {
	return isdigit(c);
}
