#include	<ctype.h>

int (isblank)(int c) {
	return isblank(c);
}
