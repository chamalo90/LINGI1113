#include	<ctype.h>

int (isprint)(int c) {
	return isprint(c);
}
