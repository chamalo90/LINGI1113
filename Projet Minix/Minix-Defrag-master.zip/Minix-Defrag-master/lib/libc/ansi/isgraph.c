#include	<ctype.h>

int (isgraph)(int c) {
	return isgraph(c);
}
